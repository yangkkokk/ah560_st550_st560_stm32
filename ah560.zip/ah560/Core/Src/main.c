/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define Setup_Key 1
#define O_Key 4
#define C_Key 0
#define T_Key 3
#define point 0x80

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c2;

TIM_HandleTypeDef htim1;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM1_Init(void);
static void MX_I2C2_Init(void);
/* USER CODE BEGIN PFP */
static void init_TM1638(void);
static void  Write_COM(uint8_t cmd);
static void Write_DATA(uint8_t add,uint8_t DATA);
static  int  Read_key(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */


 //重定向print start
//int __io_putchar(int ch)
//{
//    //具体哪个串口可以更改USART1为其它串�?
//    while ((USART1->SR & 0X40) == 0); //循环发�??,直到发�?�完�?
//    USART1->DR = (uint8_t) ch;
//    return ch;
//}
//
////_write函數在syscalls.c中， 使用__weak定义�? �?以可以直接在其他文件中定义_write函数
//__attribute__((weak)) int _write(int file, char *ptr, int len)
//{
//    int DataIdx;
//    for (DataIdx = 0; DataIdx < len; DataIdx++)
//    {
//        __io_putchar(*ptr++);
//    }
//    return len;
//}
/*********************************************************************************************/
//串口发�??
/*********************************************************************************************/
//#ifdef  __GNUC__
//#define PUTCHAR_PROTOTYPE int __IO_putchar(int ch)
//#else
//#define PUTCHAR_PROTOTYPE int fputc(int ch,FILE *f)
//#endif
//PUTCHAR_PROTOTYPE
//{
//
//	HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
//	return ch;
//}
/*********************************************************************************************/
//串口接收
/*********************************************************************************************/
//#ifdef  __GNUC__
//#define GETCHAR_PROTOTYPE int __IO_getchar()
//#else
//#define PUTCHAR_PROTOTYPE int fgetc(int ch,FILE *f)
//#endif
//GETCHAR_PROTOTYPE
//{
//
//	uint8_t ch;
//	HAL_UART_Receive(&huart1, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
//	return ch;
//}
/*********************************************************************************************/
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_TIM1_Init();
  MX_I2C2_Init();
  /* USER CODE BEGIN 2 */
  /* Private function prototypes -----------------------------------------------*/

  RetargetInit(&huart1);
//    setvbuf(stdin, NULL, _IONBF, 0);
//    setvbuf(stdout, NULL, _IONBF, 0);

  /* Private function prototypes -----------------------------------------------*/

//  uint8_t cpData[]="SYSTEM START---------------------------USART1 IS START ";
//  uint8_t cpData1[]="SYSTEM START---------------------------USART2 IS START";
//  HAL_UART_Transmit(&huart1, cpData, sizeof(cpData) , 10);
  printf("SYSTEM START---------------------------start");
//  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET);
//  HAL_UART_Transmit(&huart2, cpData1, sizeof(cpData1) , 10);
//  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
//  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
  HAL_Delay(1000);
  printf("SYSTEM START---------------------------start");
//  HAL_UART_Transmit(&huart1, cpData1, sizeof(cpData1) , 10);
//  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET);
//  HAL_UART_Transmit(&huart2, cpData1, sizeof(cpData1) , 10);
//  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
//  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
  HAL_Delay(1000);
  //uint8_t duan[6]={1,2,3,5,4,0};
  uint8_t duan[6]={0,8,10,6,4,2};
  uint8_t n1,n2,n3,n4,n5,n6;
  //0--6
  //1--1
  //2--2
  //3--3
  //4--5
  //5--4
  uint8_t tab[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,
                             0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71};
  uint8_t num[8];		//各个数码管显示的�??

  init_TM1638();	                           //初始化TM1638
  for(int i=0;i<6;i++)
	  Write_DATA(i<<1,tab[0]);	               //初始化寄存器
  for(int j=0;j<6;j++){
	  num[j]=0;
	  Write_DATA(j*2,tab[num[j]]);
	  HAL_Delay(10);
  }
 // uint8_t aTxBuffer[256] ="---------/n";
  int buffer=0;
  uint8_t state=0;
  uint16_t  Input_Result[2];
  char buf[100];
  uint8_t Buffer =0;
  uint8_t i = 0, ret;
  for(i=1; i<128; i++)
  {
      ret = HAL_I2C_IsDeviceReady(&hi2c2, (uint16_t)(i<<1), 3, 5);
      if (ret != HAL_OK) /* No ACK Received At That Address */
      {
    	  printf("0");
      }
      else if(ret == HAL_OK)
      {
    	  printf("1");
    	//  printf("0x%X", i);
    	  Buffer =i;
       //   HAL_UART_Transmit(&huart1, Buffer, sizeof(Buffer), 10000);
      }
  }
  printf("\n lcd addres is 0x%X", Buffer);



  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1)
  {
	 // while (1){}

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  //uint8_t i;
//	  uint8_t i=Read_key();                          //读按键�??

	  if (8==Read_key()){
		    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
	  for(int j=0;j<10;j++){
		//  Write_LED_On(j);
		 if(j<8){
		  Write_DATA(12,3<<j);
		  HAL_Delay(50);
		  if(j==7){Write_DATA(12,0);}
		 }
		 if(j==8){Write_DATA(13,1);HAL_Delay(50);}
		 if(j==9){Write_DATA(13,2);HAL_Delay(50);Write_DATA(13,0);buffer++;}
		 //		  Write_DATA(13,3);
		 //		  Write_DATA(12,255);
	  }
      n6 =buffer/100000 %10;
      n5 =buffer/10000 %10;
      n4 =buffer/1000 %10;
      n3 =buffer/100 %10;
      n2 =buffer/10 %10;
      n1 =buffer %10;
      Write_DATA(duan[0],tab[n6]);
      Write_DATA(duan[1],tab[n5]);
      Write_DATA(duan[2],tab[n4]);
      Write_DATA(duan[3],tab[n3]);
      Write_DATA(duan[4],tab[n2]);
      Write_DATA(duan[5],tab[n1]);

	    printf("\r\n run buffer: %d",buffer);
	      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
	  }
	//    scanf("%s", buf);
//	    printf("\r\nHello, %s!\r\n", buf);
//		uint8_t result;
//		//����Read Input Registers����
//		//�ӻ���ַ0x01 ,�Ĵ�����ַ 0x02 ,������2���Ĵ�����ַ
//		result = ModbusMaster_readInputRegisters(0x01,0x2, 2);
//		if (result == 0x00)
//		{
//			Input_Result[0] = ModbusMaster_getResponseBuffer(0x00);
//			Input_Result[1] = ModbusMaster_getResponseBuffer(0x01);
//		}
	  if(Setup_Key==Read_key()){
		  printf("\r\n Setup_Key");
		  Write_COM(0x80);

		  for(int j=0;j<6;j++){
			  num[j]=0;
			  Write_DATA(j*2,0);
			  HAL_Delay(10);
		  }
		  Write_DATA(13,3);
		  Write_DATA(12,255);
		  Write_COM(0x8b);


	  }
	  if(O_Key==Read_key()){
		  printf("\r\n O_Key");
		  for(int j=0;j<6;j++){
			  num[j]=0;
			  Write_DATA(j*2,255);
			  HAL_Delay(10);
		  }
		  Write_DATA(13,0);
		  Write_DATA(12,0);

	  }
	  if(T_Key==Read_key()){
		  printf("\r\n T_Key");
		  for(int j=0;j<6;j++){

			  Write_DATA(j*2,tab[9]);
			  HAL_Delay(10);
		  }

	  }
	  if(C_Key==Read_key()){
		  printf("\r\n C_Key");
//		  for(int j=0;j<6;j++){
//			  Write_DATA(duan[j],tab[j+1]);
//			  HAL_Delay(1);
//		  }
//		  Write_DATA(13,3);
//		  Write_DATA(12,255);

		  for(int j=0;j<10;j++){
			//  Write_LED_On(j);
			 if(j<8){
			  int a =1;
			  a =3<<j;
			  Write_DATA(12,a);
			  HAL_Delay(100);
			  if(j==7){Write_DATA(12,0);}
			 }
			 if(j==8){Write_DATA(13,1);HAL_Delay(100);}
			 if(j==9){Write_DATA(13,2);HAL_Delay(100);Write_DATA(13,0);}
			 //		  Write_DATA(13,3);
			 //		  Write_DATA(12,255);
		  }

	  }



//		if(i<8)
//		{
//		  num[i]++;
//		  while(i==Read_key())		       //等待按键释放
//		  {
//				HAL_UART_Transmit(&huart1, (uint8_t*)aTxBuffer, sprintf(aTxBuffer,"UART1 %d \n", i), 100);
//				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET);
//				HAL_UART_Transmit(&huart2, (uint8_t*)aTxBuffer, sprintf(aTxBuffer,"UART2 %d \n", i), 100);
//				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
//		  }
//		  if(num[i]>15)
//		  num[i]=0;
//		  Write_DATA(i*2,tab[num[i]]);
//		  Write_allLED(1<<i);
//		}


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.ClockSpeed = 100000;
  hi2c2.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_SlaveConfigTypeDef sSlaveConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sSlaveConfig.SlaveMode = TIM_SLAVEMODE_DISABLE;
  sSlaveConfig.InputTrigger = TIM_TS_ITR0;
  if (HAL_TIM_SlaveConfigSynchro(&htim1, &sSlaveConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */
  __HAL_UART_ENABLE_IT(&huart2,UART_IT_TC);
  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, STB_Pin|CLK_Pin|DIO_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(USART2DE_GPIO_Port, USART2DE_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_Pin */
  GPIO_InitStruct.Pin = LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : STB_Pin CLK_Pin DIO_Pin */
  GPIO_InitStruct.Pin = STB_Pin|CLK_Pin|DIO_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : USART2DE_Pin */
  GPIO_InitStruct.Pin = USART2DE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(USART2DE_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void TM1638_Write(uint8_t	DATA)			//写数据函�??
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	uint8_t i;
	  GPIO_InitStruct.Pin = DIO_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	  HAL_GPIO_WritePin(GPIOB,DIO_Pin, GPIO_PIN_RESET);

/*clk时钟高电平的时�??,dio高电平写�??1位，�??共写8�??,位地�??从低写入
 * */
  //      pinMode(DIO,OUTPUT);
	for(i=0;i<8;i++)//输出8位clk
	{
            //digitalWrite(CLK,LOW);
            HAL_GPIO_WritePin(GPIOB,CLK_Pin, GPIO_PIN_RESET);//clk输出高电�??
	    if(DATA&0X01)//�??后一位开始写�??,按位�??,�??后以为都�??1，输出dio高电�??
              // digitalWrite(DIO,HIGH);
	    	HAL_GPIO_WritePin(GPIOB,DIO_Pin, GPIO_PIN_SET);
	    else
             //  digitalWrite(DIO,LOW);
	    HAL_GPIO_WritePin(GPIOB,DIO_Pin, GPIO_PIN_RESET);
	    DATA>>=1;//写完低电平向右位�??
           // digitalWrite(CLK,HIGH);
            HAL_GPIO_WritePin(GPIOB,CLK_Pin, GPIO_PIN_SET);////clk输出低电�??
	}
}
/*�??8位，clk低电平的时�?�开始读取dio,如果读到高电平，�??高位或写�??1temp|=0x80;每循环一次，右移�??次，移动8次，倒着写入
 * */
uint8_t TM1638_Read(void)					//读数据函�??
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	uint8_t i;
	uint8_t temp=0;
	  GPIO_InitStruct.Pin = DIO_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

     //   pinMode(DIO,INPUT);//设置为输�??
	for(i=0;i<8;i++)
	{
  	    temp>>=1;
            HAL_GPIO_WritePin(GPIOB,CLK_Pin, GPIO_PIN_RESET);//时钟低电�??
            if(HAL_GPIO_ReadPin(GPIOB, DIO_Pin)==GPIO_PIN_SET)//如果读到高电平与0x80,8位最高位写入1,从低读取
  	   // if(digitalRead(DIO)==HIGH)
  	      temp|=0x80;
            HAL_GPIO_WritePin(GPIOB,CLK_Pin, GPIO_PIN_SET);//时钟高电�??

	}
	return temp;
}
void  Write_COM(uint8_t cmd)		//发�?�命令字
{
	 HAL_GPIO_WritePin(GPIOB, STB_Pin, GPIO_PIN_RESET);
        //digitalWrite(STB,LOW);
	TM1638_Write(cmd);
      //  digitalWrite(STB,HIGH);
        HAL_GPIO_WritePin(GPIOB, STB_Pin, GPIO_PIN_SET);
}
 int  Read_key(void)
{
	uint8_t c[4],i,key_value=0;
         HAL_GPIO_WritePin(GPIOB, STB_Pin, GPIO_PIN_RESET);
         //写入命令
	TM1638_Write(0x42);		           //读键扫数�?? 命令
	//�??4�??

	for(i=0;i<4;i++)
  	{
            c[i]=TM1638_Read();
        }
        HAL_GPIO_WritePin(GPIOB, STB_Pin, GPIO_PIN_SET);//4个字节数据合成一个字�??
//数据处理
        //读了4个byte,32�??
	for(i=0;i<4;i++)
	{
            key_value|=c[i]<<i;
        }
	//依次左移key_value
//	key_value|=c[1]<<i;
//	key_value|=c[2]<<i;
//	key_value|=c[3]<<i;
//	key_value|=c[4]<<i;
        for(i=0;i<8;i++)
        {
            if((0x01<<i)==key_value)//判断当前按键�?? 从低到高,哪一位有值，i就是多少
            break;
        }
	return i;
}
void Write_DATA(uint8_t add,uint8_t DATA)		//指定地址写入数据
{
	Write_COM(0x44);
         HAL_GPIO_WritePin(GPIOB, STB_Pin, GPIO_PIN_RESET);
	TM1638_Write(0xc0|add);
	TM1638_Write(DATA);
        HAL_GPIO_WritePin(GPIOB, STB_Pin, GPIO_PIN_SET);
}
void Write_allLED(uint8_t LED_flag)					//控制全部LED函数，LED_flag表示各个LED状�??
{
	uint8_t i;
	for(i=0;i<10;i++)
	{
	    if(LED_flag|(1<<i))
	      Write_DATA(2*i+1,1);
	    else
	      Write_DATA(2*i+1,0);
        }
}
void Write_LED_On(uint8_t LED_flag)					//控制全部LED函数，LED_flag表示各个LED状�??
{
//	uint8_t i;
//	for(i=0;i<10;i++)
//	{
//	    if(LED_flag|(1<<i))
//	      Write_DATA(2*i+1,1);
//	    else
//	      Write_DATA(2*i+1,0);
//        }
	uint8_t led[11]={(uint8_t)12,(uint8_t)12,(uint8_t)12,(uint8_t)12,(uint8_t)12,(uint8_t)12,(uint8_t)12,(uint8_t)12,(uint8_t)13,(uint8_t)13};
	if(LED_flag<(uint8_t)10){
		if((LED_flag=(uint8_t)8)){Write_DATA(led[LED_flag],1<<0);}
		if((LED_flag=(uint8_t)9)){Write_DATA(led[LED_flag],1<<1);}
		if(LED_flag<(uint8_t)8){Write_DATA(led[LED_flag],1<<LED_flag);}
	}

}
void Write_LED_Off(uint8_t LED_flag)					//控制全部LED函数，LED_flag表示各个LED状�??
{
//	uint8_t i;
//	for(i=0;i<10;i++)
//	{
//	    if(LED_flag|(1<<i))
//	      Write_DATA(2*i+1,1);
//	    else
//	      Write_DATA(2*i+1,0);
//        }
	uint8_t led[11]={12,12,12,12,12,12,12,12,13,13};
//	if(LED_flag<10){
//		Write_DATA(led[LED_flag],0);
//	}
	if(LED_flag<(uint8_t)10){
		if((LED_flag=(uint8_t)8)){Write_DATA(led[LED_flag],0<<0);}
		if((LED_flag=(uint8_t)9)){Write_DATA(led[LED_flag],0<<1);}
		if((LED_flag<(uint8_t)8)){Write_DATA(led[LED_flag],0<<LED_flag);}
	}
}
//TM1638初始化函�??
void init_TM1638(void)
{
	uint8_t i;
	Write_COM(0x8b);       //亮度 (0x88-0x8f)8级亮度可�??
	Write_COM(0x40);       //采用地址自动�??1
         HAL_GPIO_WritePin(GPIOB, STB_Pin, GPIO_PIN_RESET);	//stb
	TM1638_Write(0xc0);    //设置起始地址
	for(i=0;i<16;i++)	   //传�??16个字节的数据
	  TM1638_Write(0x00);	//全部写入0
        HAL_GPIO_WritePin(GPIOB, STB_Pin, GPIO_PIN_SET);//stb
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
