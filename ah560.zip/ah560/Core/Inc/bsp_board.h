/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BSP_BOARD_H
#define __BSP_BOARD_H
  /* Includes ------------------------------------------------------------------*/
//�������йص�ͷ�ļ�
#include "stm32f1xx_hal.h"

/* USER CODE END Includes */

/* Private define ------------------------------------------------------------*/

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */


#endif 
/********END OF FILE****/
